module.exports = {
  stories: ['../storybook/**/*.stories.@(tsx|mdx)'],
  addons: ['@storybook/addon-essentials'],
};
