export interface IconProps extends React.SVGAttributes<HTMLOrSVGElement> {
  size?: number;
}
